import serial
import time
import re

# === Serial Setup ===
SENSOR_PORT = '/dev/ttyACM0'       # Input from sensors and rear motor output
DIRECTION_PORT = '/dev/ttyUSB0'    # Output to steering motor
BAUD_RATE = 115200
TIMEOUT = 1

# Open ports
try:
    ser_in = serial.Serial(SENSOR_PORT, BAUD_RATE, timeout=TIMEOUT)
    ser_out = serial.Serial(DIRECTION_PORT, BAUD_RATE, timeout=TIMEOUT)
except serial.SerialException as e:
    print(f"Serial error: {e}")
    exit()

# Sensor values
d1 = d2 = d3 = d4 = None
prev_command = None
prev_command2 = None

def parse_distance(line, tag):
    match = re.search(rf"{tag} (\d+)", line)
    if match:
        return int(match.group(1))
    return None

def print_sensor_status():
    print(f"[SENSORS] D1: {d1} | D2: {d2} | D3: {d3} | D4: {d4}")

def main():
    global d1, d2, d3, d4, prev_command, prev_command2
    command = None

    while True:
        try:
            if ser_in.in_waiting:
                line = ser_in.readline().decode("utf-8", errors="ignore").strip()

                if "D1:" in line:
                    d1 = parse_distance(line, "D1:")
                elif "D2:" in line:
                    d2 = parse_distance(line, "D2:")
                elif "D3:" in line:
                    d3 = parse_distance(line, "D3:")
                elif "D4:" in line:
                    d4 = parse_distance(line, "D4:")

                # Print sensor values as they update
                print_sensor_status()

            # === REAR WHEEL CONTROL ===
            if d3 is not None:
                command2 = None

                if d3 > 20:
                    command2 = "elore"

                elif d3 < 20:
                    while True:
                        if ser_in.in_waiting:
                            line = ser_in.readline().decode("utf-8", errors="ignore").strip()

                            if "D1:" in line:
                                d1 = parse_distance(line, "D1:")
                            elif "D2:" in line:
                                d2 = parse_distance(line, "D2:")
                            elif "D3:" in line:
                                d3 = parse_distance(line, "D3:")
                            elif "D4:" in line:
                                d4 = parse_distance(line, "D4:")

                            print_sensor_status()

                        if d3 is None or d1 is None or d2 is None:
                            continue

                        if d3 < 20:
                            ser_in.write(b"hatra\n")
                            print("[REAR] hatra")

                            if d2 > d1:
                                command = "jobbra"
                            else:
                                command = "balra"

                            ser_out.write((command + "\n").encode())
                            print(f"[STEER] {command}")
                            time.sleep(0.5)

                        if (d3 and d3 > 20) or (d4 is not None and d4 < 5):
                            flip = "balra" if command == "jobbra" else "jobbra"
                            ser_out.write((flip + "\n").encode())
                            print(f"[BREAK-FLIP] {flip}")
                            break

                if command2 and command2 != prev_command2:
                    print(f"[REAR] {command2}")
                    ser_in.write((command2 + "\n").encode())
                    prev_command2 = command2
                    time.sleep(1)

            # === FRONT WHEEL CONTROL ===
            if None not in (d1, d2, d3):
                command = ""

                if d3 > 20:
                    if d1 > 10 and d2 > 10:
                        command = ""
                    elif d1 > 10 and d2 < 10:
                        command = "jobbra"
                    elif d1 < 10 and d2 > 10:
                        command = "balra"
                    else:
                        command = "jobbra" if d1 < d2 else "balra"
                elif d3 < 20:
                    if d1 > 10 and d2 > 10:
                        command = ""
                    elif d1 > 10 and d2 < 10:
                        command = "jobbra"
                    elif d1 < 10 and d2 > 10:
                        command = "balra"
                    else:
                        command = "jobbra" if d1 < d2 else "balra"

                if command != prev_command:
                    ser_out.write((command + "\n").encode())
                    print(f"[FRONT] {command}")
                    prev_command = command

            time.sleep(0.05)

        except KeyboardInterrupt:
            print("Exiting...")
            break
        except Exception as e:
            print(f"[Error] {e}")
            continue

if __name__ == "__main__":
    main()

