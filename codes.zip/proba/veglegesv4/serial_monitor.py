import serial
from collections import deque

# === Serial Configuration ===
SERIAL_PORT = '/dev/ttyACM0'  # Change to match your device
BAUD_RATE = 115200
TIMEOUT = 1

# Keep only the last 4 relevant lines (D1–D4)
data_buffer = deque(maxlen=4)

def read_serial():
    try:
        with serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=TIMEOUT) as ser:
            while True:
                if ser.in_waiting:
                    data = ser.readline().decode('utf-8', errors='ignore').strip()

                    # Accept lines containing D1, D2, D3, or D4
                    if any(tag in data for tag in ["D1:", "D2:", "D3:", "D4:"]):
                        data_buffer.append(data)

                        # Write the last 4 lines to the file
                        with open("serial_data.txt", "w") as file:
                            file.write("\n".join(data_buffer) + "\n")

                        print(data)  # Optional: for live debugging
                        
    except serial.serialutil.SerialException as e:
        print(f"[Error] {e}")

# Run the function
if __name__ == '__main__':
    read_serial()

