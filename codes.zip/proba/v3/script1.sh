#!/bin/bash

#gnome-terminal -- bash -c " bash kieg.sh ; exec bash"

gnome-terminal -- bash -c " python3 serial_monitor.py ; exec bash"
gnome-terminal -- bash -c "minicom -b 115200 -D /dev/ttyUSB0; exec bash"

#ELSO KEREKEK



function kerek () {

while true; do

  line1=$(grep -a "D1:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
  line2=$(grep -a "D2:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
  

  command=0

    

    if [[ $line1 -gt 10 && $line2 -gt 10 ]]; then
        command=""
    elif [[ $line1 -gt 10 && $line2 -lt 10 ]]; then
        command="jobbra"
    elif [[ $line1 -lt 10 && $line2 -gt 10 ]]; then
        command="balra"
    else
        if [[ $line1 -lt $line2 ]]; then
            command="jobbra"
        else
            command="balra"
        fi
    fi
        
    if [[ "$command" != "$prev_command" ]]; then
    
    	echo "$command"
    	echo "$command" > /dev/ttyUSB0
	
    	# Update previous values
    	prev_command="$command"
    	
    fi

	sleep 0.1
	
	
done
}

kerek
