#!/bin/bash

#ELSO KEREKEK

function kerek () {

while true; do

  line3=$(grep -a "D3:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
    
  command2=0
 
   
	#HATSOKEREK
	
	if [[ $line3 -lt 10 ]];then 
		
		command2="stop"
		
	else 
		command2="elore"
		
		
	fi	
	
	 if [[ "$command2" != "$prev_command2" ]]; then
	
		echo "$command2"
		echo "$command2" > /dev/ttyACM0
		prev_command2="$command2"
		sleep 0.1
	fi
	
	

	
done
}

kerek
