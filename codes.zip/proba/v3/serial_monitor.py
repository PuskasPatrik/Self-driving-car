import serial
from collections import deque

# === Serial Configuration ===
SERIAL_PORT = '/dev/ttyACM0'  # Update this to match your device
BAUD_RATE = 115200
TIMEOUT = 1

# Limit to latest 3 lines
data_buffer = deque(maxlen=3)  # Keeps only last 3 entries

def read_serial():
    try:
        with serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=TIMEOUT) as ser:
            while True:
                if ser.in_waiting:
                    data = ser.readline().decode('utf-8', errors='ignore').strip()
                    
                    # Store only D1, D2, and D3 values
                    if "D1:" in data or "D2:" in data or "D3:" in data:
                        data_buffer.append(data)  # Keep only last 3 lines
                        
                        # Write only latest 3 lines to the file
                        with open("serial_data.txt", "w") as file:  # "w" overwrites file
                            file.write("\n".join(data_buffer) + "\n")

                        print(data)  # Optional: Print to console
                    
    except serial.serialutil.SerialException as e:
        print(f"[Error] {e}")

# Run the function
if __name__ == '__main__':
    read_serial()
