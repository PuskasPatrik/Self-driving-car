import cv2
import numpy as np

# kamera inditas
cap = cv2.VideoCapture (2)

# szinhatarok
lower_green = np.array([40, 50, 50])
upper_green = np.array([80, 255, 255])

lower_red1 = np.array([0, 100, 100])
upper_red1 = np.array([10, 255, 255])
lower_red2 = np.array([160, 100, 100])
upper_red2 = np.array([179, 255, 255])

# allithato ablakok
cv2.namedWindow("Frame", cv2.WINDOW_NORMAL)
cv2.namedWindow("Green Mask", cv2.WINDOW_NORMAL)
cv2.namedWindow("Red Mask", cv2.WINDOW_NORMAL)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    mask_green = cv2.inRange(hsv, lower_green, upper_green)
    mask_red1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask_red2 = cv2.inRange(hsv, lower_red2, upper_red2)
    mask_red = cv2.bitwise_or(mask_red1, mask_red2)

    output_data = []

    # zold filter
    contours_green, _ = cv2.findContours(mask_green, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    if contours_green:
        biggest_green = max(contours_green, key=cv2.contourArea)
        area = cv2.contourArea(biggest_green)
        if area > 500:
            x, y, w, h = cv2.boundingRect(biggest_green)
            cx = x + w // 2
            cy = y + h // 2
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(frame, f"Green ({cx},{cy}) A:{int(area)}", (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            output_data.append(f"green,{cx},{cy},{int(area)}")

    # piros filter
    contours_red, _ = cv2.findContours(mask_red, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    if contours_red:
        biggest_red = max(contours_red, key=cv2.contourArea)
        area = cv2.contourArea(biggest_red)
        if area > 500:
            x, y, w, h = cv2.boundingRect(biggest_red)
            cx = x + w // 2
            cy = y + h // 2
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.putText(frame, f"Red ({cx},{cy}) A:{int(area)}", (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            output_data.append(f"red,{cx},{cy},{int(area)}")

    # mentess
    with open("colors_positions.txt", "w") as f:
        for line in output_data:
            f.write(line + "\n")

    # nyissa meg az ablakokat
    cv2.imshow("Frame", frame)
    cv2.imshow("Green Mask", mask_green)
    cv2.imshow("Red Mask", mask_red)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# takaritas
cap.release()
cv2.destroyAllWindows()

