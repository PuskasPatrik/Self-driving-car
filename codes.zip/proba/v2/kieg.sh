#!/bin/bash

#ELSO KEREKEK

function kerek () {

while true; do

  line3=$(grep -a "D3:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
    
  command2=0
 
   
	#HATSOKEREK
	
	if [[ $line3 -gt 20 ]]; then 
		
		command2="elore"
		
	elif [[ $line3 -lt 20 ]]; then  
	
		while true;
		do 
		line3=$(grep -a "D3:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
		
			line1=$(grep -a "D1:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
  			line2=$(grep -a "D2:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
		
		if [[ $line3 -lt 20 ]]; then
			echo "hatra" > /dev/ttyACM0
	
				if [[ $line2 -gt $line1 ]]; then
					command="jobbra" 
					echo "$command" > /dev/ttyUSB0
				else
					command="balra" 
					echo "$command" > /dev/ttyUSB0
				fi
			sleep 0.5
		else 
			if [[ "$command" == "jobbra" ]]; then
				echo "balra" > /dev/ttyUSB0
				break
			else
				echo "jobbra" > /dev/ttyUSB0
				break
			fi
		fi
		done
		
		
	fi	
	
	 if [[ "$command2" != "$prev_command2" ]]; then
	
		echo "$command2"
		echo "$command2" > /dev/ttyACM0
		sleep 1
		prev_command2="$command2"
		sleep 0.1
	fi
	
	

	
done
}

kerek
