#!/bin/bash
gnome-terminal -- bash -c "python3 color.py; exec bash"
gnome-terminal -- bash -c "minicom -b 115200 -D /dev/ttyACM0; exec bash"

#ELSO KEREKEK

function elso_kerek () {

while true;
do

#cat /dev/ttyACM0 > sensor_data.txt

line=$(head -n 1 /dev/ttyACM0)
line2=$(head -n 2 /dev/ttyACM0 | tail -n 1)


echo "$line"
echo "$line2"
if [[ "$line" == D1:* ]]; then
  sensor1=$(echo "$line" | grep -oP 'D1:\s*\K[0-9.]+')
  if [[ "$sensor1" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
    if (( $(echo "$sensor1 < 4" | bc -l) )); then
      echo "1balra" > /dev/ttyACM0
      echo "1balra"
    fi
  fi
fi


if [[ "$line2" == D2:* ]]; then
  sensor2=$(echo "$line2" | grep -oP 'D2:\s*\K[0-9.]+')
  if [[ "$sensor2" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
    if (( $(echo "$sensor2 < 4" | bc -l) )); then
      echo "1jobbra" > /dev/ttyACM0
      echo "1jobbra"
    fi
  fi
fi
 


#piros_meret=0
echo $piros_meret
zold_meret=$(grep -a "green" colors_positions.txt | cut -d "," -f 4 | head -n 1 )
piros_meret=$(grep -a "red" colors_positions.txt | cut -d "," -f 4 | head -n 1 )
zold_x=$(grep -a "green" colors_positions.txt | cut -d "," -f 2 | head -n 1 )
piros_x=$(grep -a "red" colors_positions.txt | cut -d "," -f 2 | head -n 1 )

if [[ "$piros_meret" -gt 3000 ]]; then 
	 
	echo $piros_x
	
	if [[ "$piros_x" -lt 300 ]]; then
    	echo "jobbra" > /dev/ttyACM0
    	echo "jobbra"
    	sleep 0.3

	elif [[ "$piros_x" -lt 600 ]]; then
   	echo "jobbra" > /dev/ttyACM0
    	sleep 0.3

	elif [[ "$piros_x" -gt 900 ]]; then
    	echo "balra" > /dev/ttyACM0
    	sleep 0.3

	elif [[ "$piros_x" -gt 600 ]]; then
    	echo "balra" > /dev/ttyACM0
    	echo "balra"
    	sleep 0.3



	else
	echo "0" > /dev/ttyACM0
	fi
else 

echo "tul messze"

fi
	
sleep 0.5
#clear
done
}











# HATSO KEREKEK
function hatso_kerek () {

while true;
do

piros_meret=0
zold_meret=$(grep -a "green" colors_positions.txt | cut -d "," -f 4 | head -n 1 )
piros_meret=$(grep -a "red" colors_positions.txt | cut -d "," -f 4 | head -n 1 )
echo $zold_meret
echo $piros_meret
 if [[ "$zold_meret" =~ ^[0-9]+$ && "$piros_meret" =~ ^[0-9]+$ ]]; then
	if [ "$zold_meret" -gt "$piros_meret" ]; then

		if [ "$zold_meret" -gt 3500 ]; then
    			echo "0" 
		elif [ "$zold_meret" -lt 3500 ]; then
    			echo "2"
    		fi
    	
	elif [ "$piros_meret" -gt "$zold_meret"  ]; then

		if [ "$piros_meret" -gt 3500 ]; then
    			echo "0" 
		elif [ "$piros_meret" -lt 3500 ]; then
    			echo "2" 
    		fi
	
elif [[ "$zold_meret" =~ ^[0-9]+$ ]]; then

		if [ "$zold_meret" -gt 3500 ]; then
    			echo "0" 
		elif [ "$zold_meret" -lt 3500 ]; then
    			echo "2" 
    		fi
elif [[ "$piros_meret" =~ ^[0-9]+$ ]]; then
		if [ "$piros_meret" -gt 3500 ]; then
    			echo "0" 
		elif [ "$piros_meret" -lt 3500 ]; then
    			echo "2" 
    		fi
else 
	echo "2" 

fi
fi
sleep 0.1
clear
done
}

torles() {
    echo "leállítás"
    kill 0
    exit 0
}

trap torles SIGINT #ctrl+c

elso_kerek 
#( hatso_kerek | awk '{print "func2 | " $0}' ) &

wait


