#!/bin/bash

gnome-terminal -- bash -c " python3 serial_monitor.py ; exec bash"
#gnome-terminal -- bash -c "minicom -b 115200 -D /dev/ttyACM0; exec bash"

#ELSO KEREKEK



function kerek () {

while true; do

  line1=$(grep -a "D1:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
  line2=$(grep -a "D2:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
  line3=$(grep -a "D3:" serial_data.txt | uniq | tail -n 1 | cut -d " " -f 2 | cut -d "." -f 1)
    
  command=0
  command2=0
    

    if [[ $line1 -gt 10 && $line2 -gt 10 ]]; then
        command="semmi"
    elif [[ $line1 -gt 10 && $line2 -lt 10 ]]; then
        command="jobbra"
    elif [[ $line1 -lt 10 && $line2 -gt 10 ]]; then
        command="balra"
    else
        if [[ $line1 -lt $line2 ]]; then
            command="jobbra"
        else
            command="balra"
        fi
    fi
    
    if [[ "$command" != "$prev_command" ]]; then
    
    	echo "$command"
    	echo "$command" > /dev/ttyACM0

    	# Update previous values
    	prev_command="$command"
    	
    fi


	#HATSOKEREK
	
	if [[ $line3 -lt 10 ]];then 
		
		command2="hatra"
		sleep 0.5
	else 
		command2="elore"
		sleep 0.5
		
	fi	
	
	 if [[ "$command2" != "$prev_command2" ]]; then
	
		echo "$command2"
		echo "$command2" > /dev/ttyACM0
		prev_command2="$command2"
	fi
	
	
	sleep 0.1
	
	
done
}

kerek
