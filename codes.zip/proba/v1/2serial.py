import serial
import time

# === Serial Configuration ===
SERIAL_PORT = '/dev/ttyACM0'  # Update this to match your device
BAUD_RATE = 115200
TIMEOUT = 1

# To track the previous commands
prev_command = ""
prev_command2 = ""

# Open serial communication for sending commands
ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=TIMEOUT)

def send_command(command):
    """Send a command via serial port"""
    if command:
        print(f"Sending command: {command}")
        ser.write(f"{command}\n".encode())  # Send command to serial device
    else:
        print("No valid command to send.")

def stop_rear_motor():
    """Stop the rear motor explicitly before turning"""
    send_command("stop")  # Send stop command for rear motor
    time.sleep(0.2)  # Short delay to ensure the motor stops

def analyze_data():
    global prev_command, prev_command2

    while True:
        # Read data from the serial port
        if ser.in_waiting:
            data = ser.readline().decode('utf-8', errors='ignore').strip()

            # Only process the relevant lines (D1, D2, D3)
            if "D1:" in data or "D2:" in data or "D3:" in data:
                # Extract values from the incoming data (e.g., D1: 12.3)
                try:
                    line1 = int(data.split(" ")[1].split(".")[0]) if "D1:" in data else None
                    line2 = int(data.split(" ")[1].split(".")[0]) if "D2:" in data else None
                    line3 = int(data.split(" ")[1].split(".")[0]) if "D3:" in data else None

                    # Skip if we couldn't extract the data correctly
                    if line1 is None or line2 is None or line3 is None:
                        continue

                    # Print the received data for debugging
                    print(f"Received Data: D1={line1}, D2={line2}, D3={line3}")

                    # Determine the command for turning (jobbra, balra, or semmi)
                    if line1 > 10 and line2 > 10:
                        command = "semmi"
                    elif line1 > 10 and line2 < 10:
                        command = "jobbra"
                    elif line1 < 10 and line2 > 10:
                        command = "balra"
                    else:
                        command = "jobbra" if line1 < line2 else "balra"

                    # Stop the rear motor before sending any turning command
                    if command != prev_command:
                        stop_rear_motor()  # Stop rear motor before turning
                        send_command(command)
                        prev_command = command

                    # Determine the command for moving forward or backward (elore, hatra)
                    if line3 < 10:
                        command2 = "hatra"
                    else:
                        command2 = "elore"

                    # Send the command2 if it's different from the previous one
                    if command2 != prev_command2:
                        send_command(command2)
                        prev_command2 = command2

                    # Sleep before the next iteration
                    time.sleep(0.1)

                except ValueError as e:
                    print(f"Error processing data: {e}")
                   

